<?php include 'header.php';?>
<main> 
	<section class="box-breadcrumbs" style="background: url('images/bread.png') no-repeat center;background-size: cover;">
		<div class="cap-bread text-center">
			<div class="container">
				<div class="info-cap cap-connect">
					<h5>Xin chào bạn!</h5>
					<h2><span>Gửi lời tâm sự yêu thương</span></h2>
					<div class="desc">
						Vườn kết nối là nơi được tạo ra để chúng ta có thể thoải mái chia sẻ, tâm sự những niềm vui, nỗi buồn, vướng mắc trong cuộc sống, tình yêu, học tập, gia đình, ...
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="box-connect">
		<div class="container">
			<div class="list-connect">
				<div class="content-connect">
					<div class="item-connect">
						<a href="vuonketnoi-detail.php" class="link-cnn"></a>
					 	<div class="top-conn">
					 		<div class="left">
					 			<div class="avr-cnn"><img src="images/vuon-1.png" class="img-fluid" alt=""></div>
					 			<div class="info">
					 				<h4>Thắng Tiến Nguyễn</h4>
					 				<div class="date">19 Thg 5, 2021</div>
					 			</div>
					 		</div>
					 		<div class="right">
					 			<ul>
					 				<li>
					 					<div class="cmt-cnn">
					 						<img src="images/cmt.png" class="img-fluid" alt=""><label>1</label>
					 					</div>
					 				</li>
					 				<li><span>1 bình luận</span></li>
					 			</ul>
					 		</div>
					 	</div>
					 	<div class="desc">
					 		Fan BTS mua 2.000 vé concert A Pink rồi hủy để... tập dượt mua vé cho concert BTS. Fan BTS mua 2.000 vé concert A Pink rồi hủy để... tập dượt mua vé cho concert BTS.
					 	</div>
					</div>
					<div class="item-connect">
						<a href="vuonketnoi-detail.php" class="link-cnn"></a>
					 	<div class="top-conn">
					 		<div class="left">
					 			<div class="avr-cnn"><img src="images/vuon-1.png" class="img-fluid" alt=""></div>
					 			<div class="info">
					 				<h4>Thắng Tiến Nguyễn</h4>
					 				<div class="date">19 Thg 5, 2021</div>
					 			</div>
					 		</div>
					 		<div class="right">
					 			<ul>
					 				<li>
					 					<div class="cmt-cnn">
					 						<img src="images/cmt.png" class="img-fluid" alt=""><label>1</label>
					 					</div>
					 				</li>
					 				<li><span>1 bình luận</span></li>
					 			</ul>
					 		</div>
					 	</div>
					 	<div class="desc">
					 		Fan BTS mua 2.000 vé concert A Pink rồi hủy để... tập dượt mua vé cho concert BTS. Fan BTS mua 2.000 vé concert A Pink rồi hủy để... tập dượt mua vé cho concert BTS.
					 	</div>
					</div>
					<div class="item-connect">
						<a href="vuonketnoi-detail.php" class="link-cnn"></a>
					 	<div class="top-conn">
					 		<div class="left">
					 			<div class="avr-cnn"><img src="images/vuon-1.png" class="img-fluid" alt=""></div>
					 			<div class="info">
					 				<h4>Thắng Tiến Nguyễn</h4>
					 				<div class="date">19 Thg 5, 2021</div>
					 			</div>
					 		</div>
					 		<div class="right">
					 			<ul>
					 				<li>
					 					<div class="cmt-cnn">
					 						<img src="images/cmt.png" class="img-fluid" alt=""><label>1</label>
					 					</div>
					 				</li>
					 				<li><span>1 bình luận</span></li>
					 			</ul>
					 		</div>
					 	</div>
					 	<div class="desc">
					 		Fan BTS mua 2.000 vé concert A Pink rồi hủy để... tập dượt mua vé cho concert BTS. Fan BTS mua 2.000 vé concert A Pink rồi hủy để... tập dượt mua vé cho concert BTS.
					 	</div>
					</div>
					<div class="item-connect">
						<a href="vuonketnoi-detail.php" class="link-cnn"></a>
					 	<div class="top-conn">
					 		<div class="left">
					 			<div class="avr-cnn"><img src="images/vuon-1.png" class="img-fluid" alt=""></div>
					 			<div class="info">
					 				<h4>Thắng Tiến Nguyễn</h4>
					 				<div class="date">19 Thg 5, 2021</div>
					 			</div>
					 		</div>
					 		<div class="right">
					 			<ul>
					 				<li>
					 					<div class="cmt-cnn">
					 						<img src="images/cmt.png" class="img-fluid" alt=""><label>1</label>
					 					</div>
					 				</li>
					 				<li><span>1 bình luận</span></li>
					 			</ul>
					 		</div>
					 	</div>
					 	<div class="desc">
					 		Fan BTS mua 2.000 vé concert A Pink rồi hủy để... tập dượt mua vé cho concert BTS. Fan BTS mua 2.000 vé concert A Pink rồi hủy để... tập dượt mua vé cho concert BTS.
					 	</div>
					</div>
					<div class="item-connect">
						<a href="vuonketnoi-detail.php" class="link-cnn"></a>
					 	<div class="top-conn">
					 		<div class="left">
					 			<div class="avr-cnn"><img src="images/vuon-1.png" class="img-fluid" alt=""></div>
					 			<div class="info">
					 				<h4>Thắng Tiến Nguyễn</h4>
					 				<div class="date">19 Thg 5, 2021</div>
					 			</div>
					 		</div>
					 		<div class="right">
					 			<ul>
					 				<li>
					 					<div class="cmt-cnn">
					 						<img src="images/cmt.png" class="img-fluid" alt=""><label>1</label>
					 					</div>
					 				</li>
					 				<li><span>1 bình luận</span></li>
					 			</ul>
					 		</div>
					 	</div>
					 	<div class="desc">
					 		Fan BTS mua 2.000 vé concert A Pink rồi hủy để... tập dượt mua vé cho concert BTS. Fan BTS mua 2.000 vé concert A Pink rồi hủy để... tập dượt mua vé cho concert BTS.
					 	</div>
					</div>
					<div class="item-connect">
						<a href="vuonketnoi-detail.php" class="link-cnn"></a>
					 	<div class="top-conn">
					 		<div class="left">
					 			<div class="avr-cnn"><img src="images/vuon-1.png" class="img-fluid" alt=""></div>
					 			<div class="info">
					 				<h4>Thắng Tiến Nguyễn</h4>
					 				<div class="date">19 Thg 5, 2021</div>
					 			</div>
					 		</div>
					 		<div class="right">
					 			<ul>
					 				<li>
					 					<div class="cmt-cnn">
					 						<img src="images/cmt.png" class="img-fluid" alt=""><label>1</label>
					 					</div>
					 				</li>
					 				<li><span>1 bình luận</span></li>
					 			</ul>
					 		</div>
					 	</div>
					 	<div class="desc">
					 		Fan BTS mua 2.000 vé concert A Pink rồi hủy để... tập dượt mua vé cho concert BTS. Fan BTS mua 2.000 vé concert A Pink rồi hủy để... tập dượt mua vé cho concert BTS.
					 	</div>
					</div>
				</div>
				<div class="pagination w-100 text-center justify-content-between">
					<ul class="list-inline text-center w-100">
						<li class="list-inline-item"><a href="">Trang trước</a></li>
						<li class="list-inline-item"><a href="" class="active">1</a></li>
						<li class="list-inline-item"><a href="">2</a></li>
						<li class="list-inline-item"><a href="">3</a></li>
						<li class="list-inline-item"><a href="">4</a></li>
						<li class="list-inline-item"><a href="">...</a></li>
						<li class="list-inline-item"><a href="">10</a></li>
						<li class="list-inline-item"><a href="">Trang sau</a></li>
					</ul>
				</div>
			</div>
		</div>
	</section>
</main> 
<?php include 'footer.php';?>     
    